This is a test of a zip file that does not contain a valid SDK.
